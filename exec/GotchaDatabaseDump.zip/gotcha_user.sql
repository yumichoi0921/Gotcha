-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: i6b102.p.ssafy.io    Database: gotcha
-- ------------------------------------------------------
-- Server version	5.7.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nick_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_role` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (31,'amugeona@gmail.com','현호짱짱','$2a$10$ggB0mMdJbXKJ8Qh0dZk0c.eWj5cLSwAvsFxx9Ilj8gZ1jQYMop5Bi','현호고수','USER'),(32,'yumichoi0921@gmail.com','도둑아니에요','$2a$10$aeJZxtWKL6TJ3IgNzYsqTOQ8.i4B36E/F.2hLzdhFgTXrwfH0P4Be','notdoduk','USER'),(33,'asdf@','wooshik','$2a$10$HAQeCz8WZFavK.0di1BiDuJSlfZMHgAqGICIYeMCvXTGd5mbSq.ii','wooshik','USER'),(34,'anananan@hanmail.net','예지라구요','$2a$10$QMHRQ7QBZolgOyQiMynv6OjCAXPC3qEJ8Z069hfzjD5ou3BTOwRTG','안예지당','USER'),(35,'cathy@naver.com','예나입니다','$2a$10$vJ5hnZPBAb7R4MLRV1FlCuAJYaoFM9u4Vnx4sxBWAKldAQXwRtqDG','예나입니다','USER'),(36,'style9604@naver.com','킹뒈킹뒈','$2a$10$vu17IAFQJoIjyftwPLsSm.VnVvwslzzP0Qr2qPmp.PeDWPtJq68qC','김두김두회','USER'),(37,'김두김두회@naver.com','까메메까메오','$2a$10$nfcToCa5MHJdmLvnHA4FM.JD11qKrVpu5VahHAHDAf.1jH3H5qK.e','김뒈는얼굴이까메오','USER'),(39,'qwe123@gmail.com','잼민이타도','$2a$10$i52JL53S9KQKH0jkGnQTv.TH0zSIYcLfoPNviz6wtCcoXIhKsQaUO','잼민이타도','USER'),(40,'ssafy@ssafy.com','ssafy','$2a$10$tSbzq5NlzP2D.v5jNSAXUOPQIL2RAmKjgDaU7ivqF5SM/7W6.qHNq','ssafy','USER');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-02-16 23:10:59
